﻿namespace MovimentacaoBancaria.Dominio.Interfaces
{
    public interface IContaCorrenteRepositorio<T> : IRepositorioBase<T>
    {
    }
}
