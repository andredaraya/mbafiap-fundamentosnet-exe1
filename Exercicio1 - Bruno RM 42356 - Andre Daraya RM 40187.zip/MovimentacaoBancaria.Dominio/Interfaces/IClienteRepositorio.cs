﻿namespace MovimentacaoBancaria.Dominio.Interfaces
{
    public interface IClienteRepositorio<T> : IRepositorioBase<T>
    {
    }
}
