﻿namespace MovimentacaoBancaria.Dominio.Interfaces
{
    public interface IContaEspecialRepositorio<T> : IRepositorioBase<T>
    {
    }
}
