﻿namespace MovimentacaoBancaria.Dominio.Models
{
    public class RespostaBase
    {
        public string Mensagem { get; set; }
        public bool Sucesso { get; set; }
    }
}
